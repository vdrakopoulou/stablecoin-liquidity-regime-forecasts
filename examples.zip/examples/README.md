# Examples

The main reproducibility check is:

```bash
python scripts/00_smoke_test.py
```

That synthetic run should populate `outputs/SMOKE_TEST/` with example HHM and NHHM export files.
